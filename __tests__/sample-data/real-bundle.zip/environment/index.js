export default {
  TESTING: '123',
}
