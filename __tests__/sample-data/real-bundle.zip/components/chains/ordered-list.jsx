import List from './generators/list.jsx'

export default List('ol')
