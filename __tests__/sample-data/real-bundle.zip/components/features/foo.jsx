export default function Foo(_) {
  return (
    <div>
      <h1>Foo.</h1>
    </div>
  )
}
